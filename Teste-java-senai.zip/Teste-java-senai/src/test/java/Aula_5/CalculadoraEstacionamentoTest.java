package Aula_5;

import org.example.Aula_5.CalculadoraEstacionamento;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CalculadoraEstacionamentoTest {

    @ParameterizedTest(
            name = "horas={0}, fim de semana={1}, esperado={2}"
    )
    @CsvSource({
            // horas, fimDeSemana, esperado
            "1,  false, 5.00",     // fronteira mínima (dia comum)
            "1,  true,  6.00",     // fronteira mínima (fim de semana) 5 * 1.2
            "2,  false, 8.00",     // vizinho interno
            "2,  true,  9.60",     // 8 * 1.2
            "23, false, 71.00",    // vizinho interno do máximo
            "23, true,  85.20",    // 71 * 1.2
            "24, false, 74.00",    // fronteira máxima
            "24, true,  88.80"     // 74 * 1.2
    })
    void calcularDeveRetornarValorCorreto(
            int horas,
            boolean fimDeSemana,
            double esperado) {

        double obtido = CalculadoraEstacionamento.calcular(horas, fimDeSemana);

        assertEquals(esperado, obtido, 0.001);
    }

    @ParameterizedTest(name = "permanência inválida: {0}")
    @ValueSource(ints = {0, -1, 25})
    void permanenciaInvalidaDeveLancarExcecao(int horas) {
        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraEstacionamento.calcular(horas, false)
        );

        assertEquals(
                "A permanência deve estar entre 1 e 24 horas.",
                excecao.getMessage()
        );
    }
}