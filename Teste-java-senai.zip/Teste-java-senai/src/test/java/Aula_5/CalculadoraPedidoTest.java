package Aula_5;

import org.example.Aula_5.CalculadoraPedido;
import org.example.Aula_5.Item;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CalculadoraPedidoTest {

    // ---------- Cenários válidos ----------
    @ParameterizedTest(name = "{0}")
    @MethodSource("cenariosDePedido")
    @Timeout(value = 1, unit = TimeUnit.SECONDS)
    void calcularDeveAtenderCenariosValidos(
            String descricao,
            Item item,
            int percentualCupom,
            double esperado) {

        double obtido = CalculadoraPedido.calcular(item, percentualCupom);

        assertEquals(esperado, obtido, 0.001, descricao);
    }

    static Stream<Arguments> cenariosDePedido() {
        return Stream.of(
                // descrição, item, cupom, esperado
                Arguments.of(
                        "sem cupom",
                        new Item("Caderno", 20.0, 2),
                        0,
                        40.0
                ),
                Arguments.of(
                        "cupom mínimo válido (1%)",
                        new Item("Caneta", 5.0, 10),
                        1,
                        49.5
                ),
                Arguments.of(
                        "cupom quase máximo (29%)",
                        new Item("Mochila", 100.0, 1),
                        29,
                        71.0
                ),
                Arguments.of(
                        "cupom máximo (30%)",
                        new Item("Livro", 50.0, 3),
                        30,
                        105.0
                ),
                Arguments.of(
                        "quantidade e preço na fronteira mínima",
                        new Item("Borracha", 0.01, 1),
                        0,
                        0.01
                )
        );
    }

    // ---------- Item nulo ----------
    @ParameterizedTest(name = "item nulo")
    @NullSource
    void itemNuloDeveLancarExcecao(Item item) {
        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraPedido.calcular(item, 10)
        );

        assertEquals("O item é obrigatório.", excecao.getMessage());
    }

    // ---------- Nome ausente / em branco ----------
    @ParameterizedTest(name = "nome inválido: [{0}]")
    @NullAndEmptySource
    @ValueSource(strings = {" ", "\t"})
    void nomeAusenteDeveLancarExcecao(String nome) {
        Item item = new Item(nome, 10.0, 1);

        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraPedido.calcular(item, 0)
        );

        assertEquals("O nome do item é obrigatório.", excecao.getMessage());
    }

    // ---------- Preço inválido ----------
    @ParameterizedTest(name = "preço inválido: {0}")
    @ValueSource(doubles = {0.0, -0.01, -10.0})
    void precoInvalidoDeveLancarExcecao(double preco) {
        Item item = new Item("Produto", preco, 1);

        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraPedido.calcular(item, 0)
        );

        assertEquals("O preço deve ser maior que zero.", excecao.getMessage());
    }

    // ---------- Quantidade inválida ----------
    @ParameterizedTest(name = "quantidade inválida: {0}")
    @ValueSource(ints = {0, -1, -5})
    void quantidadeInvalidaDeveLancarExcecao(int quantidade) {
        Item item = new Item("Produto", 10.0, quantidade);

        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraPedido.calcular(item, 0)
        );

        assertEquals("A quantidade deve ser maior que zero.", excecao.getMessage());
    }

    // ---------- Cupom inválido ----------
    @ParameterizedTest(name = "cupom inválido: {0}%")
    @ValueSource(ints = {-1, 31})
    void cupomInvalidoDeveLancarExcecao(int percentualCupom) {
        Item item = new Item("Produto", 10.0, 1);

        IllegalArgumentException excecao = assertThrows(
                IllegalArgumentException.class,
                () -> CalculadoraPedido.calcular(item, percentualCupom)
        );

        assertEquals("O cupom deve estar entre 0 e 30.", excecao.getMessage());
    }
}
