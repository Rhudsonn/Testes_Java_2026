package org.example.Aula_5;

/**
 * Calcula o valor do estacionamento.
 */
public final class CalculadoraEstacionamento {

    private CalculadoraEstacionamento() {
    }

    public static double calcular(int horas, boolean fimDeSemana) {
        if (horas < 1 || horas > 24) {
            throw new IllegalArgumentException(
                    "A permanência deve estar entre 1 e 24 horas."
            );
        }

        // Primeira hora = R$ 5,00
        // Horas adicionais = R$ 3,00 cada
        double valor = 5.0 + (horas - 1) * 3.0;

        // Final de semana: +20%
        if (fimDeSemana) {
            valor = valor * 1.20;
        }

        return valor;
    }
}
