package org.example.Aula_5;


/**
 * Calcula o frete comum ou expresso de uma entrega.
 */
public final class CalculadoraFrete {

    // Impede a criação de objetos da classe utilitária.
    private CalculadoraFrete() {
    }

    public static double calcular(
            double pesoKg,
            boolean entregaExpressa) {

        // Zero e valores negativos são inválidos.
        if (pesoKg <= 0) {
            throw new IllegalArgumentException(
                    "O peso deve ser maior que zero."
            );
        }

        // Valor base mais R$ 2,00 por quilograma.
        double freteComum = 8.0 + pesoKg * 2.0;

        // A modalidade expressa acrescenta 50%.
        if (entregaExpressa) {
            return freteComum * 1.5;
        }

        return freteComum;
    }
}
