package org.example.Aula_5;

public record Item(
        String nome,
        double precoUnitario,
        int quantidade
) {
}
